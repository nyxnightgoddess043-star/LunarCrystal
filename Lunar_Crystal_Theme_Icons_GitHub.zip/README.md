# Lunar Crystal Launcher — Android 14 / Infinix

Launcher Android prototipe bernuansa ungu-bulan-kristal berdasarkan gambar referensi.

## Fitur
- Terdaftar sebagai aplikasi HOME agar bisa dipilih sebagai layar utama default Android.
- Wallpaper Lunar Crystal sebagai latar belakang.
- Jam digital dan tanggal otomatis.
- Ikon shortcut kristal dan dock empat ikon.
- Panel cuaca dan musik bergaya widget.
- Ikon mencoba membuka aplikasi yang terpasang.
- Widget jam Android dari proyek awal tetap tersedia di pemilih widget.

## Catatan
- Cuaca saat ini hanya contoh statis (28°, Berawan, Jakarta), belum memakai layanan cuaca langsung.
- Panel musik adalah demo visual, belum menjadi kontrol media universal.
- Tampilan status/navigation bar dan nama paket aplikasi dapat berbeda di XOS.
- Tidak mengganti layar kunci, panel notifikasi, atau seluruh ikon sistem.

## Build APK lewat HP dengan GitHub Actions
1. Buat atau buka repositori GitHub.
2. Unggah semua isi ZIP ini ke root repositori (jangan unggah ZIP sebagai satu file).
3. Commit ke branch `main`.
4. Buka tab **Actions** → **Build Lunar Crystal Launcher APK** → **Run workflow**.
5. Setelah proses sukses, buka run tersebut dan unduh artifact `Lunar-Crystal-Launcher-debug-apk`.
6. Ekstrak artifact, lalu instal APK di HP.
7. Buka app dan pilih Lunar Crystal Launcher sebagai Home. Jika tidak ditanya, buka Pengaturan → Aplikasi → Aplikasi default → Aplikasi layar utama.

ZIP ini adalah source project, bukan APK siap pasang. APK dibuat oleh GitHub Actions.


## Update ikon kristal
Versi ini memasukkan ikon Musik, YouTube, Phone Manager, Catatan, Kompas, File, Jam, dan Pengaturan dari pengguna ke layar utama. Ikon berada di `app/src/main/res/drawable-nodpi/`.
Build lewat GitHub Actions dengan workflow **Build Lunar Crystal Launcher APK**.
Catatan: nama paket aplikasi tujuan dapat berbeda antarperangkat; jika suatu ikon tidak membuka aplikasi, ubah nama paket di daftar `apps` pada `MainActivity.java`.
