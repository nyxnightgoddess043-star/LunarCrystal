package com.lunarcrystal.theme;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.widget.*;
import android.view.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
 private final Handler handler=new Handler(); private TextView clock,date; private Runnable ticker;
 private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF160A39);getWindow().setNavigationBarColor(0xFF10072F);buildHome();}
 private void buildHome(){
  FrameLayout root=new FrameLayout(this); ImageView bg=new ImageView(this);bg.setImageResource(R.drawable.lunar_wallpaper);bg.setScaleType(ImageView.ScaleType.CENTER_CROP);root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
  View tint=new View(this);tint.setBackgroundColor(0x33200A62);root.addView(tint,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout screen=new LinearLayout(this);screen.setOrientation(1);screen.setPadding(dp(18),dp(4),dp(18),dp(8));root.addView(screen,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout top=new LinearLayout(this);top.setOrientation(1);top.setGravity(Gravity.CENTER_HORIZONTAL);
  top.addView(text("☾   ✧   ✦",25,0xFFE6D6FF,0),match());clock=text("10:24",58,Color.WHITE,0);clock.setTypeface(Typeface.create("serif",0));clock.setShadowLayer(dp(12),0,0,0xFFD8B6FF);top.addView(clock,match());
  date=text("",15,0xFFF0E5FF,0);top.addView(date,match());TextView quote=text("Bintang selalu bersinar\nmeski di malam paling gelap.",13,0xFFE3D4FF,2);quote.setGravity(Gravity.CENTER);LinearLayout.LayoutParams qp=match();qp.topMargin=dp(7);qp.bottomMargin=dp(8);top.addView(quote,qp);screen.addView(top,match());
  screen.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
  LinearLayout widgets=new LinearLayout(this);widgets.setGravity(Gravity.CENTER);widgets.setPadding(dp(8),dp(7),dp(8),dp(7));widgets.setBackground(panel());
  LinearLayout weather=new LinearLayout(this);weather.setOrientation(1);weather.setGravity(Gravity.CENTER);weather.addView(text("☁",31,0xFFDCCBFF,0),match());weather.addView(text("28°",28,Color.WHITE,0),match());weather.addView(text("Berawan",12,0xFFE6D6FF,0),match());weather.addView(text("Jakarta",11,0xFFE6D6FF,0),match());widgets.addView(weather,new LinearLayout.LayoutParams(0,-2,1));
  View sep=new View(this);sep.setBackgroundColor(0x66DCC8FF);widgets.addView(sep,new LinearLayout.LayoutParams(dp(1),dp(78)));
  LinearLayout music=new LinearLayout(this);music.setOrientation(1);music.setGravity(Gravity.CENTER);music.addView(text("♫  Bintang di Hatiku",14,Color.WHITE,0),match());music.addView(text("Lagu Favorit",11,0xFFE6D6FF,0),match());LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);controls.addView(text("◀",16,Color.WHITE,0),control());TextView play=text("Ⅱ",18,Color.WHITE,1);play.setBackground(circle());controls.addView(play,control());controls.addView(text("▶",16,Color.WHITE,0),control());play.setOnClickListener(v->{play.setText(play.getText().equals("Ⅱ")?"▶":"Ⅱ");Toast.makeText(this,"Kontrol musik demo; belum terhubung ke pemutar musik.",Toast.LENGTH_SHORT).show();});music.addView(controls,match());widgets.addView(music,new LinearLayout.LayoutParams(0,-2,2));LinearLayout.LayoutParams wp=match();wp.bottomMargin=dp(14);screen.addView(widgets,wp);
  String[][] apps={{"Musik","icon_music","com.google.android.apps.youtube.music"},{"YouTube","icon_youtube","com.google.android.youtube"},{"Phone Manager","icon_phone_manager","com.transsion.phonemaster"},{"Catatan","icon_notes","com.google.android.keep"},{"Kompas","icon_compass","com.android.compass"},{"File","icon_files","com.google.android.documentsui"},{"Jam","icon_clock","com.google.android.deskclock"},{"Pengaturan","icon_settings","com.android.settings"}};
  LinearLayout grid=new LinearLayout(this);grid.setOrientation(1);for(int r=0;r<2;r++){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);for(int c=0;c<4;c++){String[] a=apps[r*4+c];row.addView(tile(a[0],a[1],a[2],false),new LinearLayout.LayoutParams(0,dp(91),1));}grid.addView(row,match());}LinearLayout.LayoutParams gp=match();gp.bottomMargin=dp(10);screen.addView(grid,gp);
  LinearLayout dock=new LinearLayout(this);dock.setGravity(Gravity.CENTER);dock.setPadding(dp(8),dp(6),dp(8),dp(6));dock.setBackground(panel());String[][] da={{"Telepon","☎","com.google.android.dialer"},{"Pesan","▤","com.google.android.apps.messaging"},{"Tema","✿","com.lunarcrystal.theme"},{"Browser","◉","com.android.chrome"}};for(String[] a:da)dock.addView(tile(a[0],a[1],a[2],true),new LinearLayout.LayoutParams(0,dp(57),1));screen.addView(dock,match());TextView foot=text("✦   LUNAR CRYSTAL   ✦",10,0xFFE6D6FF,0);LinearLayout.LayoutParams fp=match();fp.topMargin=dp(4);screen.addView(foot,fp);setContentView(root);updateClock();ticker=()->{updateClock();handler.postDelayed(ticker,15000);};handler.postDelayed(ticker,15000);
 }
 private View tile(String label,String glyph,String pkg,boolean dock){LinearLayout t=new LinearLayout(this);t.setOrientation(1);t.setGravity(Gravity.CENTER);int s=dock?dp(49):dp(56);if(!dock){ImageView icon=new ImageView(this);int res=getResources().getIdentifier(glyph,"drawable",getPackageName());if(res!=0)icon.setImageResource(res);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);t.addView(icon,new LinearLayout.LayoutParams(s,s));TextView name=text(label,10,Color.WHITE,0);name.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=match();p.topMargin=dp(2);t.addView(name,p);}else{TextView icon=text(glyph,26,Color.WHITE,0);icon.setGravity(Gravity.CENTER);icon.setBackground(crystal());t.addView(icon,new LinearLayout.LayoutParams(s,s));}t.setOnClickListener(v->launch(pkg,label));return t;}
 private void launch(String pkg,String label){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){startActivity(i);return;}if(label.equals("Telepon"))startActivity(new Intent(Intent.ACTION_DIAL));else if(label.equals("Kamera"))startActivity(new Intent("android.media.action.IMAGE_CAPTURE"));else if(label.equals("Tema"))Toast.makeText(this,"Lunar Crystal Launcher aktif",Toast.LENGTH_SHORT).show();else startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){Toast.makeText(this,"Aplikasi tidak tersedia: "+label,Toast.LENGTH_SHORT).show();}}
 private void updateClock(){if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));if(date!=null)date.setText(new SimpleDateFormat("EEE, d MMM yyyy",new Locale("id","ID")).format(new Date()));}
 private TextView text(String s,int size,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",style));t.setGravity(Gravity.CENTER);t.setShadowLayer(dp(3),0,0,0x887C54FF);return t;}
 private GradientDrawable gradient(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xCC7658D9,color,0xCC29185E});d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}
 private android.graphics.drawable.Drawable panel(){return gradient(0xAA25165C,0xFFD7BFFF,20);}private android.graphics.drawable.Drawable crystal(){return gradient(0xCC4D37A0,0xFFE9D8FF,18);}private android.graphics.drawable.Drawable circle(){GradientDrawable d=gradient(0xFF8C6FE0,0xFFF1E5FF,50);d.setShape(GradientDrawable.OVAL);return d;}
 private LinearLayout.LayoutParams match(){return new LinearLayout.LayoutParams(-1,-2);}private LinearLayout.LayoutParams control(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(32),dp(32));p.setMargins(dp(4),dp(5),dp(4),0);return p;}
 @Override protected void onResume(){super.onResume();updateClock();}@Override protected void onDestroy(){super.onDestroy();if(ticker!=null)handler.removeCallbacks(ticker);}
}
